document.addEventListener('DOMContentLoaded', () => {
    const lessonItems = document.querySelectorAll('.lesson-item');

    const updateLessonStatus = (lessonId, isCompleted, isDisabled, isLocked) => {
        const lessonItem = document.querySelector(`.lesson-item[data-lesson-id="${lessonId}"]`);
        if (!lessonItem) return;

        if (isCompleted) {
            lessonItem.classList.add('completed');
            lessonItem.classList.remove('disabled', 'locked');
            lessonItem.style.pointerEvents = 'auto'; // Ensure clickable even if completed
            lessonItem.href = `licao${lessonId}.html`; // Ensure link is defined
        } else if (isDisabled && isLocked) {
            lessonItem.classList.remove('completed');
            lessonItem.classList.add('disabled', 'locked');
            lessonItem.style.pointerEvents = 'none'; // Disable click
            lessonItem.href = '#'; // Prevent navigation
        } else { // This is the "active" or "next" lesson state
            lessonItem.classList.remove('completed', 'disabled', 'locked');
            lessonItem.style.pointerEvents = 'auto'; // Enable click
            lessonItem.href = `licao${lessonId}.html`; // Restore link
        }
    };

    const loadLessonStatuses = () => {
        // First, mark all lessons as disabled/locked by default, except the first one
        lessonItems.forEach(item => {
            const lessonId = parseInt(item.dataset.lessonId);
            if (lessonId > 1) { // All lessons after the first are initially locked
                updateLessonStatus(lessonId, false, true, true);
            }
        });

        // Then, check and enable lessons based on localStorage
        for (let i = 1; i <= lessonItems.length; i++) {
            const isCompleted = localStorage.getItem(`lesson-${i}-completed`) === 'true'; // LocalStorage key
            if (isCompleted) {
                updateLessonStatus(i, true, false, false); // Mark as completed
            } else {
                // If the current lesson is NOT completed, check if the previous one IS completed
                // This means the current lesson should be active (not locked)
                if (i === 1 || localStorage.getItem(`lesson-${i-1}-completed`) === 'true') { // LocalStorage key
                    updateLessonStatus(i, false, false, false); // Mark as active/next
                }
            }
        }
    };

    loadLessonStatuses(); // Call on page load

    // Add click event to each lesson item
    lessonItems.forEach(item => {
        item.addEventListener('click', (event) => {
            const lessonId = parseInt(item.dataset.lessonId);

            // Only proceed if the lesson is NOT disabled/locked
            if (!item.classList.contains('disabled') && !item.classList.contains('locked')) {
                // Mark the current lesson as completed in localStorage
                localStorage.setItem(`lesson-${lessonId}-completed`, 'true'); // LocalStorage key
                updateLessonStatus(lessonId, true, false, false); // Visually update the current lesson

                // Enable the next lesson
                const nextLessonId = lessonId + 1;
                if (nextLessonId <= lessonItems.length) {
                    // Mark the next lesson as active/next (not completed, not disabled, not locked)
                    updateLessonStatus(nextLessonId, false, false, false);
                }
            } else {
                // Prevent navigation if disabled
                event.preventDefault();
            }
        });
    });
});